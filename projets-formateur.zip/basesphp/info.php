<?php

    phpinfo();

?>
