<html>
    <head>
        <title>Tableaux PHP</title>
    </head>
    <body>
        <h1>Tableaux PHP</h1>

        <h2>Tableaux numériques</h2>
        <?php
            $tabNum = ['un', 'deux', 'trois'];

            // echo $tabNum . "<br />";
            print_r($tabNum);
            echo "<br />";    
        ?>
        <p>
            Accéder à un élément du tableau : <br />
            <?php
                echo "Elément à l'indice 1 : " . $tabNum[1] . "<br />";
            ?>
        </p>
        <p>
            Remplacer une valeur du tableau : <br />
            <?php
                $tabNum[1] = "DEUX";
                print_r($tabNum);
                echo "<br />"; 
            ?>
        </p>
        <p>
            Ajouter à la suite du tableau : <br />
            <?php
                $tabNum[] = "quatre";                // Sans indice, on ajoute à la suite...
                print_r($tabNum);
                echo "<br />";
            ?>
        </p>
        <p>
            Parcourir un tableau : <br />
            <?php
                foreach($tabNum as $element) {      // $element est une variable qui représente l'élément courant
                    echo $element . "<br />";
                }
            ?>
        </p>
        <h2>Tableaux Associatifs</h2>
        <?php
            $tabAsso = ['un' => 1, 'deux' => 2, 'trois' => 3];
            print_r($tabAsso);
            echo "<br />";
        ?>
        <p>
            Accéder à un élément du tableau : <br />
            Elément à la clé 'deux' : <?php echo $tabAsso['deux']; ?> <br />
        </p>
        <p>
            Remplacer une valeur du tableau : <br />
            <?php
                $tabAsso['deux'] = 20;
                print_r($tabAsso);
                echo "<br />"; 
            ?>
        </p>
        <p>
            Ajouter à la suite du tableau : <br />
            <?php
                $tabAsso['quatre'] = 4;                // Sans indice, on ajoute à la suite...
                print_r($tabAsso);
                echo "<br />";
            ?>
        </p>
        <p>
            Parcourir un tableau : <br />
            <?php
                foreach($tabAsso as $cle => $valeur) {      // $element est une variable qui représente l'élément courant
                    echo $cle . " = " . $valeur . "<br />";
                }
            ?>
        </p>
        <p>
            Nombre d'éléments d'un tableau : <br />
            <?php
                echo count($tabAsso);
            ?>
        </p>

        <h2>Tableaux multi-dimensionnels</h2>
        <p>
            <?php
                // Solution 1 : Décomposer
                $tabFrance = ['Paris', 'Nantes', 'Rennes'];
                $tabItalie = ['Rome', 'Venise'];
                
                // 1. A
                $tab = ['FRANCE' => $tabFrance, 'ITALIE' => $tabItalie];

                // 1. B
                $tab['FRANCE'] = $tabFrance;
                $tab['ITALIE'] = $tabItalie;

                echo "<pre>";
                print_r($tab);
                echo "</pre>";
                echo "<br />";

                // Solution 2 : Une seule instruction
                $tab = [
                    'FRANCE' => 
                        ['Paris', 'Nantes', 'Rennes']
                    , 
                    'ITALIE' => 
                        ['Rome', 'Venise']
                ];

                echo "<pre>";
                print_r($tab);
                echo "</pre>";
                echo "<br />";

            ?>
        </p>
        <p>
                Parcourir le tableau : <br />
                <?php
                    // On a besoin des clés et des valeurs
                    foreach($tab as $pays => $tabVilles) {
                        echo $pays . "<br />";
                        // On a pas besoin des clés
                        foreach($tabVilles as $ville) {
                            echo $ville . "<br />";
                        }
                    }

                ?>

        </p>


    </body>
</html>  