<html>
    <head>
        <title>Structures PHP</title>
    </head>
    <body>
        <h1>Structures PHP</h1>

        <h2>if / elseif / else</h2>
        <?php
            $a = 2;
            $b = 3;

            // Syntaxe 1 : La plus répandue...
            if($a > $b) {       // Accolades facultatives si l'on a une seule instruction
                echo "a est supérieur à b.<br />";
            }
            elseif($a < $b) {
                echo "a est inférieur à b.<br />";
            }
            else {
                echo "a est égal à b.<br />";                    
            }

            // Syntaxe 2
            if($a > $b):
                echo "a est supérieur à b.<br />";
            elseif($a < $b):
                echo "a est inférieur à b.<br />";
            else:
                echo "a est égal à b.<br />";                    
            endif;
        ?>

        <h2>switch / case / default</h2>
        <?php
            $valeur = 2;

            // On évalue les valeurs possibles de $valeur
            switch($valeur) {
                case 0: 
                    $message = "Valeur 0 récupérée.<br />";
                    break;
                case 1: 
                    $message = "Valeur 1 récupérée.<br />";
                    break;
                case 2: 
                    $message = "Valeur 2 récupérée.<br />";
                    break;
                case 3: 
                    $message = "Valeur 3 récupérée.<br />";
                    break;
                default:
                    $message = "Valeur incorrecte récupérée.<br />";
            }

            echo $message; 
            
            $reponse = 'o';

            switch($reponse) {
                case 'o':
                case 'O':
                case 'y':
                case 'Y':
                    $message = "Réponse positive !<br />";
                    break;
                case 'n':
                case 'N':
                    $message = "Réponse négative !<br />";
                    break;
                default:
                    $message = "Je n'ai pas compris la réponse !<br />";
            }

            echo $message; 

        ?>

        <h2>match / default</h2>
        <?php
            $valeur = 2;

            $message = match($valeur) {
                0 => "Valeur 0 récupérée.<br />",
                1 => "Valeur 1 récupérée.<br />",
                2 => "Valeur 2 récupérée.<br />",
                3 => "Valeur 3 récupérée.<br />",
                default => "Valeur inconnue récupérée.<br />",
            };
            echo $message;
        

            $reponse = 'o';
            $message = match($reponse) {
                'o','O','y','Y' => "Valeur positive !<br />",
                'n','N' => "Valeur négative !<br />",
                default => "Valeur inconnue !<br />"
            };    
            echo $message;
        ?>

        <h2>while</h2>
        <?php
            $x = 0;
            while($x > 0) {             // TANT QUE $x est > à 0...
                echo "Valeur de x : " . $x . "<br />";
                $x--;                   // Pour faire varier la condition
            }
        ?>
        <h2>do ... while</h2>
        <?php
            $x = 0;
            do {
                echo "Valeur de x : " . $x . "<br />";
                $x--;                   // Pour faire varier la condition
            }
            while($x > 0);              // TANT QUE $x est > à 0...
        ?>

        <h2>for</h2>
        <?php
            for($indice = 0; $indice < 4; $indice++) { // Pour indice = 0, tant que indice < 4, on incrémente indice
                echo "Valeur de indice : " . $indice . "<br />";
            }
        ?>

        <h2>break / continue</h2> 
        <p>break</p>
        <?php
            for($indice = 0; $indice < 4; $indice++) { // Pour indice = 0, tant que indice < 4, on incrémente indice
                if($indice == 2)
                    break;
                echo "Valeur de indice : " . $indice . "<br />";
            }    
        ?>
        <p>continue</p>
        <?php
            for($indice = 0; $indice < 4; $indice++) { // Pour indice = 0, tant que indice < 4, on incrémente indice
                if($indice == 2)
                    continue;
                echo "Valeur de indice : " . $indice . "<br />";
            }    
        ?>



    </body>
</html>