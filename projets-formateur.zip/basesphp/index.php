<?php
    $aujourdhui = date('d/m/Y');   // Date du jour
    const EMAIL = "elanglet@eni.fr";
    $entier = 120;
    $chaine = "Une chaine de caractères";
?>
<html>
    <head>
        <title>Première Page PHP</title>
    </head>
    <body>
        <h1>Première Page PHP</h1>
        <!-- Commentaire HTML -->
        <p>
            Nous sommes le <?php echo $aujourdhui; ?><br />
            <?php echo "Nous sommes le $aujourdhui<br />"; ?>
            <?php echo 'Nous sommes le $aujourdhui<br />'; ?>

            Utiliser la concaténation pour éviter les ambiguités : <br />
            
            <?php echo "Nous sommes le " . $aujourdhui . "<br />"; ?>
            <?php echo 'Nous sommes le ' . $aujourdhui . '<br />'; ?>

            Choisir en guillemets et apostrophes : <br />

            <?php echo 'c\'est l\'été'; ?><br />
            <?php echo "c'est l'été"; ?><br />

            Contacter l'administrateur du site : <?php echo EMAIL; ?><br /> 

            Utilisation de la fonction var_dump() : <br />
            <?php var_dump($entier); ?> <br />
            <?php var_dump($chaine); ?> <br />

            Conversion d'un entier en chaine : <br />
            <?php
                $chaineEntiere = (string) $entier;      // On converti $entier en 'string'        
                var_dump($chaineEntiere);
            ?>

            Conversion d'une chaine en entier : <br />
            <?php
                $age = "44 ans";
                $entierAge = (int) $age;
                var_dump($entierAge);
            ?>


        </p>

    </body>
</html>