<?php
    require_once('lib/fonctions.php');
    include('fragments/entete.php');
?>
    <h3>Ceci est la page d'accueil de Mon super-site</h3>

    <?php
        // Appel de la fonction addition()
        $somme = addition(12, 56);
        echo "Résultat de l'addition : " . $somme . "<br />";
    
        $moy = moyenne(12, 12, 56, 85);
        echo "Résultat de la moyenne : " . $moy . "<br />";
        echo "Résultat de la moyenne (arrondie) : " . round($moy, 2) . "<br />";

        
    ?>



<?php
    include('fragments/pied.php');
?>




