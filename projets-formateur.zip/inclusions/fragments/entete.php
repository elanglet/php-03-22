<html>
    <head>
        <title>Mon super-site !</title>
    </head>
    <body>
        <h1>Mon super-site !</h1>
