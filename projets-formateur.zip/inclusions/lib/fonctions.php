<?php

    function addition(int $operande1, int $operande2) : int {
        $resultat = $operande1 + $operande2;
        return $resultat;
    }

    function moyenne(int ...$valeurs) : float {
        if(count($valeurs) > 0) {
            $somme = 0;
            foreach($valeurs as $val) {
                $somme += $val;
            }
            return $somme / count($valeurs);
        }
    }

?>