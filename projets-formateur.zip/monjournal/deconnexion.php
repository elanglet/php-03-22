<?php
    // Pour supprimer efficacement une session il faut : 
    //   - Appeler session_start()
    //   - Vider le tableau $_SESSION -> lui affecter un tableau vide
    //   - Appeler session_destroy()
    session_start();
    $_SESSION = [];
    session_destroy();


    // On redirige vers la page d'accueil
    header('Location: index.php');

?>
