<?php
    // On vérifie la présence d'une session
    session_start();
    // On vérifie que la clé 'auteur' est absente du tableau $_SESSION
    if(!isset($_SESSION['auteur'])) {
        // Pas de session ! On redirige vers 'authentification.php'
        header('Location: authentification.php');
    }
    else {
?>
<html>
    <head>
        <title>Bienvenue sur MonJournal !</title>
    </head>
    <body>
        <h1>Bienvenue sur MonJournal !</h1>

        <h2>Rediger un article</h2>

        <form action="enregistrer.php" method="post" enctype="multipart/form-data">
            <label>Titre : </label>
            <input type="text" name="titre"  />
            <br />

            <label>Introduction : </label>
            <textarea cols="50" rows="5" name="intro"></textarea>
            <br />

            <label>Texte : </label>
            <textarea cols="50" rows="15" name="texte"></textarea>
            <br />

            <label>Auteur : </label>
            <input type="text" name="auteur" />
            <br />

            <label>Photo : </label>
            <input type="file" name="photo" />
            <br />

            <button type="submit">Enregistrer</button>
        </form>

    </body>
</html>

<?php
    }
?>
