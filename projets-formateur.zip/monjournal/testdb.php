<?php

require_once('db/ArticlePDO.php');
require_once('db/DBUtil.php');
require_once('classes/Publication.php');
require_once('classes/Article.php');    

$listeDesArticles = ArticlePDO::rechercherTousLesArticles();
$article1 = ArticlePDO::rechercherArticleParId(3);

?>
<html>
    <head>
        <title>MonJournal</title>
    </head>
    <body>
        <h1>MonJournal</h1>

        <h2>Liste de tous les articles</h2>
        <pre>
        <?php
            print_r($listeDesArticles);

        ?>
        </pre>

        <h2>Article par id (1)</h2>
        <pre>
        <?php
            print_r($article1);
        ?>
        </pre>

        <h2>Ajout d'un article</h2>
        <?php
            $article = new Article(
                0, 
                "Article à insérer",
                date('Y/m/d H:i:s'),
                "Intro de article à insérer",    
                "Texte de article à insérer",
                "Etienne LANGLET"
            );

            $id = ArticlePDO::ajouterArticle($article);
            
            echo "Id généré : " . $id;
        ?>

    </body>
</html>
