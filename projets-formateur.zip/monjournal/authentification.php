<?php

require_once('classes/Auteur.php');
require_once('db/DBUtil.php');
require_once('db/AuteurPDO.php');

// On test la présence des clés dans le tableau $_POST pour savoir si l'on est en POST ou en GET
if(isset($_POST['identifiant']) && isset($_POST['motdepasse'])) {
    // En POST : On traite le formulaire
    $auteur = AuteurPDO::authentifier($_POST['identifiant'], $_POST['motdepasse']);
    if($auteur == null) {
        // Echec de l'authentification
        // On renvoi vers l'affichage du formulaire
        // On transmet le paramètre error=true pour conditionner l'affichage du message d'erreur.
        header('Location: authentification.php?error=true');
    }
    else {
        // Authentification OK. On renvoi vers le formulaire de rédaction.

        // On créé une session
        session_start();
        // On stocke une information dans la session
        $_SESSION['auteur'] = $auteur;

        header('Location: rediger.php');
    }
}
else {
    // En GET : On affiche le formulaire
?>
<html>
    <head>
        <title>Bienvenue sur MonJournal !</title>
    </head>
    <body>
        <h1>Bienvenue sur MonJournal !</h1>
        
        <h2>Authentification</h2>
        <?php
            if(isset($_GET['error']) && $_GET['error'] == 'true') {
        ?>
            <p style="color: red;">
                Erreur d'authentification
            </p>
        <?php
            }
        ?>
        <form action="authentification.php" method="post">
            <label>Identifiant : </label>
            <input type="text" name="identifiant" />
            <br />

            <label>Mot de passe : </label>
            <input type="password" name="motdepasse" />
            <br />

            <button type="submit">Valider</button> 
        </form>

    </body>
</html>    

<?php
}
?>
