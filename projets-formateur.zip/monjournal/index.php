<?php

require_once('db/ArticlePDO.php');
require_once('db/DBUtil.php');
require_once('classes/Publication.php');
require_once('classes/Article.php');

$listeDesArticles = ArticlePDO::rechercherTousLesArticles();

// On appelle session_start() pour vérifier la présence d'une session et afficher le lien de déconnexion
session_start();

?>
<html>
    <head>
        <title>Bienvenue sur MonJournal !</title>
    </head>
    <body>
        <h1>Bienvenue sur MonJournal !</h1>

        <?php
            if(isset($_SESSION['auteur'])) {
        ?>
            <p>
                <a href="deconnexion.php">Déconnexion</a>
            </p>
        <?php
            }
        ?>

        <?php
            foreach($listeDesArticles as $article) {
        ?>
                <h2>
                    <?php echo $article->getTitre(); ?>
                </h2>
                <p>
                    <b>
                        Ecrit par <?php echo $article->getAuteur(); ?>, le <?php echo $article->getDate(); ?>
                    </b>
                </p>
                <p>
                    <i>
                        <?php echo $article->getIntro(); ?>
                    </i>
                </p>
                <p>
                    <a href="article.php?id=<?php echo $article->getId(); ?>">Lire la suite...</a>
                </p>    
                <hr />
        <?php
            }
        ?>
    </body>
</html>
