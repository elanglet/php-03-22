<?php

class Video extends Publication implements Diffusable {

    private string $resolution;
    private string $format;
    private int $duree;

    public function __construct(int $id, string $titre, string $date, string $resolution, string $format, string $duree) {
        parent::__construct($id, $titre, $date);
        $this->resolution = $resolution;
        $this->format = $format;
        $this->duree = $duree;
    }

    public function getResolution() : string {
        return $this->resolution;
    }

    public function getFormat() : string {
        return $this->format;
    }

    public function getDuree() : string {
        return $this->duree;
    }

    public function afficher() : string {
        return parent::afficher() . " - " . $this->resolution . " - " . $this->format . " - " . $this->duree;
    }

    // On redéfini la méthode abstraite en l'implémentant...
    public function publier() : void {
        echo "Publication de la vidéo...";
    }

    // On redéfini la méthode diffuser() de l'interface Diffusable
    public function diffuser(): void {
        echo "Diffusion de la vidéo...";
    }
}

?>