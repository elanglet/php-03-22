<?php

class Auteur {

    private string $identifiant;
    private string $motDePasse;
    private string $prenom;
    private string $nom;

    public function __construct(string $identifiant, string $motDePasse, string $prenom, string $nom) {
        $this->identifiant = $identifiant;
        $this->motDePasse = $motDePasse;
        $this->prenom = $prenom;
        $this->nom = $nom;
    }

    public function getIdentifiant() : string {
        return $this->identifiant;
    }

    public function getMotDePasse() : string {
        return $this->motDePasse;
    }

    public function setMotDePasse($motDePasse) : void {
        $this->motDePasse = $motDePasse;
    }
 
    public function getPrenom() : string {
        return $this->prenom;
    }

    public function setPrenom($prenom) : void {
        $this->prenom = $prenom;
    }

    public function getNom() : string {
        return $this->nom;
    }

    public function setNom($nom) : void {
        $this->nom = $nom;
    }
}

?>