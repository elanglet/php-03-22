<?php

class Podcast extends Publication implements Diffusable {

    private string $format;

    public function __construct(int $id, string $titre, string $date, string $format) {
        parent::__construct($id, $titre, $date);
        $this->format = $format;
    }

    public function getFormat() : string {
        return $this->format;
    }

    public function publier(): void {
        echo "Publication du podcast...";
    }

    // On redéfini la méthode diffuser() de l'interface Diffusable
    public function diffuser(): void {
        echo "Diffusion du podcast...";
    }
}

?>