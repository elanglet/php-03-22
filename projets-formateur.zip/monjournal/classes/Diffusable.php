<?php

interface Diffusable {

    function diffuser() : void;

}

?>  