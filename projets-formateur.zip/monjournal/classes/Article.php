<?php

class Article extends Publication {

    // Attributs qui s'ajoutent à ceux hérités de la classe Publication
    private string $intro;
    private string $texte;
    private string $auteur;

    // On définit un constructeur pour initialiser les attributs : 
    //  - hérités de Publication
    //  - propres à Article
    public function __construct(int $id, string $titre, string $date, string $intro, string $texte, string $auteur) {

        // On appelle le constructeur de la super-classe pour initialiser les attributs hérités.
        parent::__construct($id, $titre, $date);

        $this->intro = $intro;
        $this->texte = $texte;
        $this->auteur = $auteur;
    }
    
    public function getIntro() : string {
        return $this->intro;
    }

    public function setIntro(string $intro) : void {
        $this->intro = $intro;
    }

    public function getTexte() : string {
        return $this->texte;
    }

    public function setTexte(string $texte) : void {
        $this->texte = $texte;
    }

    public function getAuteur() : string {
        return $this->auteur;
    }

    public function setAuteur(string $auteur) : void {
        $this->auteur = $auteur;
    }

    // Redéfinition de la méthode afficher()
    public function afficher(): string {
        // On appelle la méthode afficher() de Publication
        $messageParent = parent::afficher();

        // On ajoute les informations de Article
        $message = $messageParent . " - " . $this->intro . " - " . $this->texte . " - " . $this->auteur;
        return $message;
    }

    // On redéfini la méthode abstraite en l'implémentant...
    public function publier(): void {
        echo "Publication de l'article'...";
    }
}

?>