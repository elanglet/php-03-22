<?php

abstract class Publication {

    // Déclaration des attributs
    private int $id;
    private string $titre;
    private string $date;

    // Attribut de classe (static) pour compter le nombre de publications
    private static int $nombreDePublications = 0;
    
    // Définition d'un constructeur : il sert à initialiser les attributs.
    public function __construct(int $id, string $titre, string $date) {
        // On initialise les attributs avec les valeurs reçues en paramètre
        $this->id = $id;
        $this->titre = $titre;
        $this->date = $date;

        // On incrémente le compteur. On accède à l'attribut avec 'self' ou bien le nom de la classe.
        self::$nombreDePublications++;
        // Ou bien : 
        // Publication::$nombreDePublications++;
    }

    // Déclaration des méthodes
    public function afficher() : string {
        // On construit une chaine à partir de l'id, du titre et de la date.
        
        // Pour accéder aux attributs de l'objet en cours de manipulation, on utilise : $this->attribut

        // ATTENTION : 
        // 
        //   On écrit : $this->date
        //   Et pas : $this->$date
        //

        $message = $this->id . " - " . $this->titre . " - " . $this->date;
        return $message;
    }

    public function getId() : int {
        return $this->id;
    }

    public function getTitre() : string {
        return $this->titre;
    }

    public function setTitre(string $titre) : void {
        $this->titre = $titre;
    }

    public function getDate() : string {
        return $this->date;
    }

    public function setDate(string $date) : void {
        $this->date = $date;
    }

    // Définition d'une méthode abstraite. Elle devra être redéfinie dans les sous-classes
    public abstract function publier() : void;

    // Méthode de classe pour l'attribut de classe
    public static function getNombreDePublications() : int {
        return self::$nombreDePublications;
        // Ou bien :
        // return Publication::$nombreDePublications;
    }
}

?>