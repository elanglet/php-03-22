<?php
// On inclu le fichier qui contient la définition de la classe
require_once('classes/Publication.php');
require_once('classes/Diffusable.php');
require_once('classes/Article.php');
require_once('classes/Video.php');
require_once('classes/Podcast.php');

// Créer un objet Publication - Plus possible dès que la classe est abstraite
// $pub = new Publication(1, "Ma Première publication !", date('Y/m/d H:i:s'));

// // On accède aux attributs pour les initialiser...
// $pub->id = 1;
// $pub->titre = "Ma Première publication !";
// $pub->date = date('Y/m/d H:i:s');

$art = new Article(
    2, 
    "Premier article !", 
    date('Y/m/d H:i:s'), 
    "Intro de premier article ...",
    "Texte de premier article",
    "Etienne LANGLET"
);

$vid = new Video(3, "Première vidéo", date('Y/m/d H:i:s'), "1920x1080", "MP4", 23);
$pod = new Podcast(4, "Premier podcast", date('Y/m/d H:i:s'), "mp3");

?>
<html>
    <head>
        <title>MonJournal</title>
    </head>
    <body>
        <h1>MonJournal</h1>
        <?php
            // Appel de la méthode sur l'objet
            // echo $pub->afficher();

            // Changer le titre
            // $pub->setTitre("Nouveau Titre !");
        ?>

        <h4><?php // echo $pub->getTitre(); ?></h4>

        <hr />
        <h4><?php echo $art->getTitre(); ?></h4>
        <p>
            <?php echo $art->getTexte(); ?>
        </p>
        <p>
            <?php echo $art->afficher(); ?>
        </p>

        <hr />
        <h4><?php echo $vid->getTitre(); ?></h4>
        <p>
            <?php echo $vid->afficher(); ?>
        </p>
        <p>
            <pre>
            <?php
                print_r($vid);
            ?>
            </pre>
        </p>

        <hr />
        <h4><?php echo $pod->getTitre(); ?></h4>
        <p>
            <pre>
            <?php
                print_r($pod);
            ?>
            </pre>
        </p>

        <h2>Manipuler les publications</h2>
        <?php
            // On récupère toutes les publications dans un tableau...
            $publications = [$art, $vid, $pod];

            // On veut diffuser tout ce que peut l'être...
            foreach($publications as $p) {
                // Si $p est Diffusable, alors on appelle la méthode diffuser()
                if($p instanceof Diffusable) {
                    $p->diffuser();
                    echo "<br />";
                }
            }
        ?>

        <hr />
        <p>
            Nombre de publications : <?php echo Publication::getNombreDePublications(); ?>
        </p>

    </body>
</html>
