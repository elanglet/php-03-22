<html>
    <head>
        <title>Bienvenue sur MonJournal !</title>
    </head>
    <body>
        <h1>Bienvenue sur MonJournal !</h1>

        <h2>Erreur !!!</h2>

        <p>
            Message : <?php echo $message; ?>        
        </p>
        <p>
            <a href="index.php">Retour à l'accueil</a>
        </p>

    </body>
</html>