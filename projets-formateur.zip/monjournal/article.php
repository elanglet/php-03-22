<?php

require_once('db/ArticlePDO.php');
require_once('db/DBUtil.php');
require_once('classes/Publication.php');
require_once('classes/Article.php');

// Avant d'utiliser la valeur de l'id transmis, on doit vérifier que :
//    - Un id est bien transmis, i.e. : La clé 'id' existe bien dans $_GET.    -> isset()
//    - La valeur de l'id est bien numérique.                                  -> is_numeric()
if(isset($_GET['id']) && is_numeric($_GET['id'])) {

    $id = $_GET['id'];
    $article = ArticlePDO::rechercherArticleParId($id);

    // On vérifie qu'on a bien récupéré un article
    if($article != null) {
?>
        <html>
            <head>
                <title>Bienvenue sur MonJournal !</title>
            </head>
            <body>
                <h1>Bienvenue sur MonJournal !</h1>
                <h2>
                    <?php echo $article->getTitre(); ?>
                </h2>
                <p>
                    <b>
                        Ecrit par <?php echo $article->getAuteur(); ?>, le <?php echo $article->getDate(); ?>
                    </b>
                </p>
                <p>
                    <i>
                        <?php echo $article->getIntro(); ?>
                    </i>
                </p>
                
                <?php
                    // On vérifie qu'une photo existe pour l'article.
                    $photo = 'images/photo_' . $id . '.jpg';
                    if(file_exists($photo)) {                    
                ?>
                    <p>
                        <img src="<?php echo $photo; ?>" />
                    </p>
                <?php
                    }
                ?>

                <p>
                    <?php echo $article->getTexte(); ?>
                </p>    
                <hr />
                <p>
                    <a href="index.php">Retour à l'accueil</a>
                </p>
            </body>
        </html>

<?php
    }
    else {
        // Erreur : Article n'existe pas dans la base
        
        // On valorise la variable $message utilisée par 'erreur.php'
        $message = "L'article n'existe pas !";
        // On inclut 'erreur.php'
        include('erreur.php');
    }
}
else {
    // Erreur : l'id n'est pas dans l'URL ou bien n'est pas numérique
    $message  = "Erreur de transmission de l'id d'article.";
    include('erreur.php');
}
?>