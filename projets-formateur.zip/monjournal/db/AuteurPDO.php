<?php

class AuteurPDO {

    // La méthode retourne : 
    //    - Un objet Auteur si l'authentification abouti
    //    - NULL dans le cas contraire
    public static function authentifier(string $identifiant, string $motDePasse) : ?Auteur {
        $cnx = DBUtil::connexion();
        $sql = "SELECT nom, prenom FROM auteur WHERE identifiant=:identifiant AND motDePasse=:motDePasse";

        $stmt = $cnx->prepare($sql);
        $stmt->bindValue(':identifiant', $identifiant);
        $stmt->bindValue(':motDePasse', $motDePasse);

        $stmt->execute();

        if($enreg = $stmt->fetch()) {
            // 1 enreg. -> Authentification OK
            // On créé un objet Auteur et on le retourne
            $auteur = new Auteur(
                $identifiant,
                $motDePasse,
                $enreg['prenom'],
                $enreg['nom']
            ); 

            return $auteur;
        }
        else {
            return null;
        }
    }
}

?>