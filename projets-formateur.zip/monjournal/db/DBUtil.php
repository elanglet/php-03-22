<?php

class DBUtil {

    private static string $url = "mysql:host=localhost;port=3306;dbname=monjournal";
    private static string $username = "monjournal";
    private static string $password = "EykZuKN4vNdtB2B";
    
    private static array $options = [PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'];

    // Méthode de classe de création d'une connexion
    public static function connexion() : PDO {
        // Pour créer la connexion, on instancie la classe PDO en passant en argument l'url, le nom d'utilisateur 
        // et le mot de passe.
        $cnx = new PDO(self::$url, self::$username, self::$password, self::$options);

        // Demander à PDO de générer des exceptions en cas de problème.
        $cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        return $cnx;
    }


}   

?>