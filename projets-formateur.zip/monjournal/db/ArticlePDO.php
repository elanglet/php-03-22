<?php

// Classe de manipulation des articles en base de données
class ArticlePDO {

    public static function rechercherTousLesArticles() : array {
        // 1. Connexion 
        $cnx = DBUtil::connexion();

        // 2. Expression de la requête SQL
        $sql = "SELECT * FROM article ORDER BY date DESC";

        // 3. Exécution de la requête (simple)
        $resultat = $cnx->query($sql);

        // 4. Exploitation des résultats

        // On créé un tableau vide pour y mettre les objets 'Article'
        $listeArticles = [];
        // On parcours le tableau d'enregistrement pour créer un tableau d'objets Article
        foreach($resultat as $enreg) {
            // On créé un objet Article à partir de l'enregistrement
            $a = new Article(
                $enreg['id'],
                $enreg['titre'],
                $enreg['date'],
                $enreg['intro'],
                $enreg['texte'],
                $enreg['auteur']
            );
            // On ajoute l'article au tableau
            $listeArticles[] = $a;
        }

        // 5. Libérer les ressources (connexion)
        $cnx = null;

        return $listeArticles;
    }

    public static function rechercherArticleParId(int $id) : ?Article {  // ?Article : Retourne 'Article' ou null
        // 1. Connexion
        $cnx = DBUtil::connexion();

        // 2. Requête SQL
        $sql = "SELECT * FROM article WHERE id=:idArticle";     // :idArticle est une variable d'une requête préparée.

        // 2bis. Préparation de la requête
        $stmt = $cnx->prepare($sql);                // On envoi la requête au serveur de base de données
                                                    // Il la stocke en cache.
                                                    // $stmt est de type PDOStatement
        $stmt->bindValue(':idArticle', $id);        // On affecte une valeur aux variables de la requête.

        // 3. Exécution de la requête
        $stmt->execute();

        // 4. Exploitation des résultats
        if($enreg = $stmt->fetch()) {
            // Article trouvé !
            // On créé un objet Article à partir de l'enregistrement.
            $a = new Article(
                $enreg['id'],
                $enreg['titre'],
                $enreg['date'],
                $enreg['intro'],
                $enreg['texte'],
                $enreg['auteur']
            );
            return $a;
        }
        else {
            return null;
        }
    }

    public static function ajouterArticle(Article $article) : int {
        $cnx = DBUtil::connexion();

        $sql = "INSERT INTO article(titre, date, intro, texte, auteur) VALUES(:titre, :date, :intro, :texte, :auteur)";
        
        $stmt = $cnx->prepare($sql);
        $stmt->bindValue(':titre', $article->getTitre());
        $stmt->bindValue(':date', $article->getDate());
        $stmt->bindValue(':intro', $article->getIntro());
        $stmt->bindValue(':texte', $article->getTexte());
        $stmt->bindValue(':auteur', $article->getAuteur());

        $stmt->execute();

        return $cnx->lastInsertId();
    }

}

?>