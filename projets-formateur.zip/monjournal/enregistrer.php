<?php

require_once('db/ArticlePDO.php');
require_once('db/DBUtil.php');
require_once('classes/Publication.php');
require_once('classes/Article.php');

// On vérifie l'absence de la session
session_start();
if(!isset($_SESSION['auteur'])) {
    header('Location: authentification.php');
}
else {

    // 1. Récupérer / Contrôler les données transmises
    //     - Les clés du tableaux $_POST sont bien présentes -> isset()
    //     - Il y a bien des données saisies dans les champs -> empty()
    if(
        isset($_POST['titre']) && !empty($_POST['titre']) && 
        isset($_POST['intro']) && !empty($_POST['intro']) &&
        isset($_POST['texte']) && !empty($_POST['texte']) &&
        isset($_POST['auteur']) && !empty($_POST['auteur']) 
    ) {
        // 2. On créé un objet Article
        $article = new Article(
            0,
            $_POST['titre'],
            date('Y/m/d H:i:s'),
            $_POST['intro'],
            $_POST['texte'],
            $_POST['auteur']
        );

        // 3. Insérer l'article
        $idGenere = ArticlePDO::ajouterArticle($article);

        // -------------------------------------------------------------------
        // Traitement de la photo
        // -------------------------------------------------------------------
        // On vérifie qu'un fichier à été transféré. La clé du champ de formulaire doit exister dans $_FILES
        if(isset($_FILES['photo'])) {
            // On vérifie que le transfert s'est bien passé
            if($_FILES['photo']['error'] == UPLOAD_ERR_OK) {
                // Contrôler le fichier reçu...
                if($_FILES['photo']['type'] == 'image/jpeg') {
                    // Fichier OK.
                    // On le déplace dans le dossier 'images' du projet avec le nom 'photo_ID.jpg'
                    $destination = 'images/photo_' . $idGenere . '.jpg';
                    // On déplace le fichier
                    move_uploaded_file($_FILES['photo']['tmp_name'], $destination);
                }
                else {
                    $message = "Erreur de format de fichier...";
                    include('erreur.php');
                    exit(); // Arrêter l'exécution du script    
                }
            }
            else {
                // Erreur de transfert...
                $message = "Erreur de transfert de fichier...";
                include('erreur.php');
                exit(); // Arrêter l'exécution du script
            }
        }


        // 4. On redirige vers la page d'affichage de l'article (article.php?id=...)
        header('Location: article.php?id=' . $idGenere);
    }
    else {
        // Erreur : Le formulaire n'a pas été transmis !
        // On redirige vers le formulaire
        header('Location: rediger.php');
    }
}
?>